var SherdBookmarkletOptions = {
    flickr_apikey:'1234567890abcdefghijklmnopqrstuvwxyz',
    host_url:'http://mediathread.ccnmtl.columbia.edu/save/',
    user_url:'http://mediathread.ccnmtl.columbia.edu/accounts/logged_in.js',
    cross_origin:true
}